import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { NewcompComponent } from './newcomp/newcomp.component';
import { BgComponent } from './bg/bg.component'; 

@NgModule({
  declarations: [
    AppComponent,
    BgComponent,
    NewcompComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent,BgComponent,NewcompComponent]
})
export class AppModule { }
