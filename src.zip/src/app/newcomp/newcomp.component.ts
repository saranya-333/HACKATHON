// import { Component,EventEmitter, Output} from '@angular/core';

// @Component({
//   selector: 'app-newcomp',
//   standalone: false,
//   templateUrl: './newcomp.component.html',
//   styleUrl: './newcomp.component.css'
// })
// export class NewcompComponent {
//   @Output() close = new EventEmitter<void>();
 
//   closeForm() {

//     this.close.emit();
//   }
// }



import { Component,EventEmitter, Output } from '@angular/core';
import { AppointmentService } from '../appointment-service.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-newcomp',
  templateUrl: './newcomp.component.html',
  styleUrls: ['./newcomp.component.css'],
  standalone:false
})
export class NewcompComponent {

  @Output() close = new EventEmitter<void>();
  closeForm() {
    this.close.emit();
 }
appointment: any = {
  appointmentId: 0,
  patientId: '',
  name: '',
  doctorId: '',
  doctorName: '',
  appointmentDate: '',
  slot: ''
};



  constructor(private appointmentService: AppointmentService) {}

  onSubmit(form: NgForm): void {
    if (form.valid) {
      this.appointmentService.saveAppointment(this.appointment).subscribe({
        next: (res) => {
          console.log('Appointment saved:', res);
          alert('Appointment saved successfully!');
          form.resetForm();
        },
        error: (err) => {
          console.error('Error saving appointment:', err);
          alert('Error saving appointment!');
        }
      });
    }
  }
}
