import { Component } from '@angular/core';

@Component({
  selector: 'app-bg',
  standalone: false,
  templateUrl: './bg.component.html',
  styleUrl: './bg.component.css'
})
export class BgComponent {
  showForm = false;
  openForm() {
    this.showForm = true;
  }
  closeForm() {
    this.showForm = false;
  }

}
