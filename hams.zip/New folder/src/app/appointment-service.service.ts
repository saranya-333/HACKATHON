import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  private baseUrl = 'http://localhost:4200/appointments'; // Adjust as needed

  constructor(private http: HttpClient) {}

  saveAppointment(appointment: any): Observable<any> {
    return this.http.post<any>({this.baseUrl}/save, appointment);
  }
}